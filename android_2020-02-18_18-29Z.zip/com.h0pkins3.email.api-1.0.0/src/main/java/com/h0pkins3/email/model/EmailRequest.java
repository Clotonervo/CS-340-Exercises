/*
 * Copyright 2010-2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *  http://aws.amazon.com/apache2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

package com.h0pkins3.email.model;


public class EmailRequest {
    /**
     * The to email address
     */
    @com.google.gson.annotations.SerializedName("to")
    private String to = null;
    /**
     * The from email address
     */
    @com.google.gson.annotations.SerializedName("from")
    private String from = null;
    /**
     * The email&#39;s subject
     */
    @com.google.gson.annotations.SerializedName("subject")
    private String subject = null;
    /**
     * The plain text email content
     */
    @com.google.gson.annotations.SerializedName("textBody")
    private String textBody = null;
    /**
     * The HTML email content
     */
    @com.google.gson.annotations.SerializedName("htmlBody")
    private String htmlBody = null;

    /**
     * The to email address
     *
     * @return to
     **/
    public String getTo() {
        return to;
    }

    /**
     * Sets the value of to.
     *
     * @param to the new value
     */
    public void setTo(String to) {
        this.to = to;
    }

    /**
     * The from email address
     *
     * @return from
     **/
    public String getFrom() {
        return from;
    }

    /**
     * Sets the value of from.
     *
     * @param from the new value
     */
    public void setFrom(String from) {
        this.from = from;
    }

    /**
     * The email&#39;s subject
     *
     * @return subject
     **/
    public String getSubject() {
        return subject;
    }

    /**
     * Sets the value of subject.
     *
     * @param subject the new value
     */
    public void setSubject(String subject) {
        this.subject = subject;
    }

    /**
     * The plain text email content
     *
     * @return textBody
     **/
    public String getTextBody() {
        return textBody;
    }

    /**
     * Sets the value of textBody.
     *
     * @param textBody the new value
     */
    public void setTextBody(String textBody) {
        this.textBody = textBody;
    }

    /**
     * The HTML email content
     *
     * @return htmlBody
     **/
    public String getHtmlBody() {
        return htmlBody;
    }

    /**
     * Sets the value of htmlBody.
     *
     * @param htmlBody the new value
     */
    public void setHtmlBody(String htmlBody) {
        this.htmlBody = htmlBody;
    }

}
