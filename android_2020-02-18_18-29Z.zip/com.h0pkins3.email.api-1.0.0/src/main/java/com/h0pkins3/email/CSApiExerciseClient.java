/*
 * Copyright 2010-2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *  http://aws.amazon.com/apache2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

package com.h0pkins3.email;

import java.util.*;

import com.h0pkins3.email.model.EmailRequest;
import com.h0pkins3.email.model.EmailResult;
import com.h0pkins3.email.model.Empty;


@com.amazonaws.mobileconnectors.apigateway.annotation.Service(endpoint = "https://84u7bervbd.execute-api.us-west-2.amazonaws.com/dev")
public interface CSApiExerciseClient {


    /**
     * A generic invoker to invoke any API Gateway endpoint.
     * @param request
     * @return ApiResponse
     */
    com.amazonaws.mobileconnectors.apigateway.ApiResponse execute(com.amazonaws.mobileconnectors.apigateway.ApiRequest request);
    
    /**
     * 
     * 
     * @param body 
     * @return EmailResult
     */
    @com.amazonaws.mobileconnectors.apigateway.annotation.Operation(path = "/sendemail", method = "POST")
    EmailResult sendemailPost(
            EmailRequest body);
    
    /**
     * 
     * 
     * @return Empty
     */
    @com.amazonaws.mobileconnectors.apigateway.annotation.Operation(path = "/sendemail", method = "OPTIONS")
    Empty sendemailOptions();
    
    /**
     * 
     * 
     * @return Empty
     */
    @com.amazonaws.mobileconnectors.apigateway.annotation.Operation(path = "/sendemail/{to}", method = "OPTIONS")
    Empty sendemailToOptions();
    
    /**
     * 
     * 
     * @param emailSubject 
     * @param emailText 
     * @param from 
     * @param to 
     * @return EmailResult
     */
    @com.amazonaws.mobileconnectors.apigateway.annotation.Operation(path = "/sendemail/{to}/{from}", method = "POST")
    EmailResult sendemailToFromPost(
            @com.amazonaws.mobileconnectors.apigateway.annotation.Parameter(name = "EmailSubject", location = "header")
            String emailSubject,
            @com.amazonaws.mobileconnectors.apigateway.annotation.Parameter(name = "EmailText", location = "header")
            String emailText,
            @com.amazonaws.mobileconnectors.apigateway.annotation.Parameter(name = "from", location = "path")
            String from,
            @com.amazonaws.mobileconnectors.apigateway.annotation.Parameter(name = "to", location = "path")
            String to);
    
    /**
     * 
     * 
     * @return Empty
     */
    @com.amazonaws.mobileconnectors.apigateway.annotation.Operation(path = "/sendemail/{to}/{from}", method = "OPTIONS")
    Empty sendemailToFromOptions();
    
}

