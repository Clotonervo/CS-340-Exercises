package net.response;

import models.User;

public class LoginResponse extends Response{

    private User user;
    private String authToken;

    public LoginResponse(String message) {
        super(false, message);
        this.user = null;
    }

    public LoginResponse(User user){
        super(true, null);
        this.user = user;
    }

    public String getMessage() {
        return super.getMessage();
    }

    public boolean isSuccess() {
        return super.isSuccess();
    }

    public User getUser()
    {
        return user;
    }

    public void setUser(User user)
    {
        this.user = user;
    }

    public String getAuthToken(){
        return this.authToken;
    }

    public void setAuthToken(String authToken){
        this.authToken = authToken;
    }
}
